 #importing the module so it can be call in the code
import datetime                                       

# Get the current date and time using the module command and assign it to the variable "now"
now = datetime.datetime.now()

# Print the date and time of variable "now" 
print("Current date and time:", now)